<?php

namespace App\ApiController;

use App\Entity\Todo;
use App\Form\TodoType;
use App\Repository\TodoRepository;
use Doctrine\Common\Collections\ArrayCollection;
use FOS\RestBundle\Controller\AbstractFOSRestController;
use FOS\RestBundle\View\View;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use FOS\RestBundle\Controller\Annotations as Rest;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * @Route("/todo", host="api.todo.do")
 */
class TodoController extends AbstractFOSRestController
{
    /**
     * @Rest\Get(
     *     path="/",
     *     name="api_todo_index"
     * )
     */
    public function index(TodoRepository $todoRepository): View
    {
        $data = $todoRepository->findAll();
        $todos = [];
        foreach ( $data as $todo ) {
            array_push($todos, $this->normalize($todo));
        }
        return View::create($todos, Response::HTTP_OK);
    }

    /**
     * @Rest\Get(
     *     path = "/{id}",
     *     name = "api_todo_show",
     * )
     * @Rest\View()
     * @param Todo $todo
     * @return View
     */
    public function getOne(Todo $todo): View
    {
        $todo = $this->normalize($todo);
        return View::create($todo, Response::HTTP_OK);
    }

    /**
     * Patch a Todo
     * @Rest\Patch(
     *     path = "/{id}/patch/done",
     *     name = "api_patch_done_todo",
     * )
     * @Rest\View()
     * @param Request $request
     * @param Todo $todo
     * @return View;
     */
    public function patchDone(Request $request, Todo $todo): View
    {
        if ($todo)
        {
            $done = $request->get('done');
            $done = $done == 'true' ? true: false;
            $todo->setDone($done);
            $em = $this->getDoctrine()->getManager();
            $em->persist($todo);
            $em->flush();
        }
        $todo = $this->normalize($todo);
        return View::create($todo, Response::HTTP_OK);
    }

    private function normalize($object)
    {
        $serializer = new Serializer([new ObjectNormalizer()]);
        $object = $serializer->normalize($object, 'json',
            ['attributes' => [
                'id',
                'title',
                'done',
                'description',
                'urlimage' => ['id','url'],
                'labels' => ['id', 'title'],
                'priority' => ['id','name','value'],
                'comments' => ['id','content']
            ]]);
        return $object;
    }
}

<?php

namespace App\ApiController;

use App\Entity\Priority;
use App\Form\PriorityType;
use App\Repository\PriorityRepository;
use FOS\RestBundle\Controller\AbstractFOSRestController;
use FOS\RestBundle\View\View;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use FOS\RestBundle\Controller\Annotations as Rest;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * @Route("/priority", host="api.todo.do")
 */
class PriorityController extends AbstractFOSRestController
{
    /**
     * @Rest\Get(
     *     path="/",
     *     name="api_priority_index"
     * )
     */
    public function index(PriorityRepository $priorityRepository): View
    {
        $data = $priorityRepository->findAll();
        $priorities = [];
        foreach ( $data as $priority ) {
            array_push($priorities, $this->normalize($priority));
        }
        return View::create($priorities, Response::HTTP_OK);
    }

    /**
     * @Rest\Get(
     *     path="/{id}",
     *     name="api_priority_show"
     * )
     */
    public function show(Priority $priority): View
    {
        $priority = $this->normalize($priority);
        return View::create($priority, Response::HTTP_OK);
    }

    /**
     * @Rest\Put(
     *     path="/{id}/edit",
     *     name="api_priority_edit"
     * )
     */
    public function edit(Priority $priority, Request $request): View
    {
        $name = $request->get('name');
        $value = $request->get('value');
        $priority->setName($name);
        $priority->setValue($value);

        $em = $this->getDoctrine()->getManager();
        $em->persist($priority);
        $em->flush();

        $priority = $this->normalize($priority);
        return View::create($priority, Response::HTTP_OK);
    }
    /**
     * @Rest\Delete(
     *     path="/{id}/delete",
     *     name="api_priority_delete"
     * )
     */
    public function delete(Priority $priority): View
    {
        $em = $this->getDoctrine()->getManager();
        $em->remove($priority);
        $em->flush();

        return View::create(array(), Response::HTTP_OK);
    }

    /**
     * @Rest\Post(
     *     path="/create",
     *     name="api_priority_create"
     * )
     */
    public function create(Request $request): View
    {
        $name = $request->get('name');
        $value = $request->get('value');

        $priority = new Priority();
        $priority->setName($name);
        $priority->setValue($value);

        $em = $this->getDoctrine()->getManager();
        $em->persist($priority);
        $em->flush();

        $priority = $this->normalize($priority);
        return View::create($priority, Response::HTTP_CREATED);
    }

    private function normalize($object)
    {
        $serializer = new Serializer([new ObjectNormalizer()]);
        $object = $serializer->normalize($object, 'json',
            ['attributes' => [
                'id',
                'name',
                'value'
            ]]);
        return $object;
    }
}

<?php

namespace App\ApiController;

use App\Entity\Label;
use App\Form\LabelType;
use App\Repository\LabelRepository;
use FOS\RestBundle\Controller\AbstractFOSRestController;
use FOS\RestBundle\View\View;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use FOS\RestBundle\Controller\Annotations as Rest;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * @Route("/label", host="api.todo.do")
 */
class LabelController extends AbstractFOSRestController
{
    /**
     * @Rest\Get(
     *     path="/",
     *     name="api_label_index"
     * )
     */
    public function index(LabelRepository $labelRepository): View
    {
        $data = $labelRepository->findAll();
        $labels = [];
        foreach ( $data as $label ) {
            array_push($labels, $this->normalize($label));
        }
        return View::create($labels, Response::HTTP_OK);
    }

    private function normalize($object)
    {
        $serializer = new Serializer([new ObjectNormalizer()]);
        $object = $serializer->normalize($object, 'json',
            ['attributes' => [
                'id',
                'title'
            ]]);
        return $object;
    }
}
